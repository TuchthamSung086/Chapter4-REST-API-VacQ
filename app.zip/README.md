# VacQ

This repository is for assignments of SOFT DEV PRAC 2022/2. 

By TUCHTHAM SUNGKAMEKA 6331313021.
